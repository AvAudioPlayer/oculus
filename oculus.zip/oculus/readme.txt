=== Oculus ===
Contributors: potatoooooo
Donate link: http://yundun.aliyun.com/
Tags: comments, spam
Requires at least: 3.0.0
Tested up to: 4.4
Stable tag: 3.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Oculus checks your comments against the Alibaba Yundun Antispam to see if they look like spam or not.

== Description ==

Oculus checks your comments against the Alibaba Yundun Antispam to see if they look like spam or not and lets you
review the spam it catches under your blog's "Comments" admin screen.

Major features in Oculus 0.1 include:

* When guest write comments , oculus record user behavior information such as mouse click , mouse move and so on.
* Oculus will check the device info of guest to see if they are hacker.

PS: You'll need an [Alibaba Yundun Appkey](http://www.aliyun.com/product/antifraud) to use it.  Appkeys are free for personal blogs, with paid subscriptions available for businesses and commercial sites.

== Installation ==

Upload the Oculus plugin to your blog, Activate it, then enter your [Alibaba Yundun Appkey](http://www.aliyun.com/product/antifraud).

You're done!

== Changelog ==

= 0.1 =
* The startup.
* checks your comments against the Alibaba Yundun Antispam to see if they look like spam
